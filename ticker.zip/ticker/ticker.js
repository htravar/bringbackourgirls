var $ = function (id) { return document.getElementById(id); }

var tickermsg = function(){
  var now = new Date();
  var day_kidnapped = Date.parse("April 14, 2014");
  var current_date = Date.parse(now);
  var days_gone = current_date - day_kidnapped;
  var numdays = days_gone/86400000;
  numdays = Math.round(numdays);
  var message = "200+ Chibok girls missing...." + numdays+" days. #BringBackOurGirls";
  
  $("marquee").innerHTML = message;
}

window.onload = function(){
  tickermsg();
}